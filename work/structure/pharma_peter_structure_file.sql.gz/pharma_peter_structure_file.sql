# Dump created on 2004-06-15 16:41
# Remember that you must use my restorescript in order to get a working DB
# because I use a special code to mark the end of a command.
# This is NOT compatible with other restorescripts!
# Anyway, have fun with this but use it at your own risk. :-) 
# This file is only Structure of the Database without Data 
DROP TABLE IF EXISTS `abteilung`;[n.!!e_w._!]
CREATE TABLE `abteilung` (
  `id` smallint(6) NOT NULL default '0',
  `bezeichnung` varchar(50) default NULL
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `artikel_darreichungsform`;[n.!!e_w._!]
CREATE TABLE `artikel_darreichungsform` (
  `id` char(3) NOT NULL default '',
  `bezeichnung` varchar(250) NOT NULL default ''
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `artikel_nr_suffix`;[n.!!e_w._!]
CREATE TABLE `artikel_nr_suffix` (
  `id` bigint(20) NOT NULL auto_increment,
  `bezeichnung` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `artikel_stammdaten`;[n.!!e_w._!]
CREATE TABLE `artikel_stammdaten` (
  `id` bigint(20) NOT NULL auto_increment,
  `nr` varchar(100) NOT NULL default '',
  `matchcode` varchar(255) default NULL,
  `bezeichnung` varchar(255) NOT NULL default '',
  `beschreibung` mediumblob,
  `verpackung` bigint(20) default NULL,
  `verpackungsmenge` float default '0',
  `verpackungseinheit` int(11) NOT NULL default '1',
  `kleinste_verkaufsmenge` float NOT NULL default '1',
  `anbieter` varchar(255) default NULL,
  `foto` varchar(255) default NULL,
  `warengruppe_intern` varchar(255) default NULL,
  `warengruppe_extern` varchar(40) default NULL,
  `meldebestand` bigint(20) default NULL,
  `mwst` int(11) NOT NULL default '0',
  `avk` float default NULL,
  `grossopreis` float default NULL,
  `angelegt_am` bigint(20) default NULL,
  `verkaufssperre` tinyint(4) default NULL,
  `sperrdatum` bigint(20) default NULL,
  `sperre_durch` bigint(20) default NULL,
  `fehlerhaft` tinyint(4) NOT NULL default '0',
  `lagerort_bereich` bigint(20) NOT NULL default '0',
  `lagerort_gang` int(11) default NULL,
  `lagerort_feld` int(11) default NULL,
  `lagerort_fach` int(11) default NULL,
  `aek` float default NULL,
  `suffix_nr` int(11) NOT NULL default '1',
  `verkehrsstatus_intern` varchar(255) default NULL,
  `verkehrsstatus_extern` varchar(255) default NULL,
  `verpackungsverordnung` tinyint(1) NOT NULL default '0',
  `vertriebsweg_grosshandel` tinyint(1) default '0',
  `hinweis` mediumblob NOT NULL,
  `darreichungsform` char(3) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `artikel_verpackung`;[n.!!e_w._!]
CREATE TABLE `artikel_verpackung` (
  `id` bigint(20) NOT NULL auto_increment,
  `bezeichnung` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `artikel_verpackungseinheit`;[n.!!e_w._!]
CREATE TABLE `artikel_verpackungseinheit` (
  `id` bigint(20) NOT NULL auto_increment,
  `bezeichnung` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `auftraege`;[n.!!e_w._!]
CREATE TABLE `auftraege` (
  `id` bigint(20) NOT NULL auto_increment,
  `kundennr` bigint(20) NOT NULL default '0',
  `auftragsnr` varchar(100) default NULL,
  `packer` bigint(20) default '0',
  `kommissionierer` smallint(5) default '0',
  `packstuecke` bigint(20) default '0',
  `tour` smallint(5) default '0',
  `erfassungsdatum` bigint(20) default '0',
  `packdatum` bigint(20) default '0',
  `lieferdatum` bigint(20) default '0',
  `bezahldatum` bigint(20) default '0',
  `status` smallint(5) default '0',
  `auftragsannahme` mediumint(9) default '0',
  PRIMARY KEY  (`id`),
  KEY `kundennr` (`kundennr`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `auftrag_artikel`;[n.!!e_w._!]
CREATE TABLE `auftrag_artikel` (
  `id_auftrag` bigint(20) NOT NULL default '0',
  `id_artikel` bigint(20) NOT NULL default '0',
  `menge` float NOT NULL default '0',
  `preis` float NOT NULL default '0'
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `auftrag_status`;[n.!!e_w._!]
CREATE TABLE `auftrag_status` (
  `id` bigint(20) NOT NULL default '0',
  `bezeichnung` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `benutzer_menu`;[n.!!e_w._!]
CREATE TABLE `benutzer_menu` (
  `user_id` int(11) default NULL,
  `menu_id` int(11) default NULL,
  `recht` tinyint(2) default NULL,
  `ordnerzustand` tinyint(1) default '1',
  KEY `menu_id` (`menu_id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `besuchsprotokoll`;[n.!!e_w._!]
CREATE TABLE `besuchsprotokoll` (
  `id` bigint(20) NOT NULL auto_increment,
  `kundennr` bigint(20) NOT NULL default '0',
  `vertreter` int(11) NOT NULL default '0',
  `besuchsdatum` bigint(20) NOT NULL default '0',
  `preisinfo` varchar(255) NOT NULL default '',
  `bemerkung` mediumblob NOT NULL,
  `wiedervorlage` char(3) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `einstellungen`;[n.!!e_w._!]
CREATE TABLE `einstellungen` (
  `user_id` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `wert` varchar(50) NOT NULL default ''
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `kunden`;[n.!!e_w._!]
CREATE TABLE `kunden` (
  `kundennr` smallint(5) unsigned NOT NULL default '0',
  `firmenname` varchar(100) default NULL,
  `parmapharm` tinyint(1) default '0',
  `vertreter` smallint(5) unsigned default NULL,
  `inhaber` varchar(100) default NULL,
  `strasse` varchar(100) default NULL,
  `plz` varchar(12) default NULL,
  `ort` varchar(100) default NULL,
  `telefon` varchar(20) default NULL,
  `fax` varchar(20) default NULL,
  `blz` varchar(16) default NULL,
  `bank` varchar(100) default NULL,
  `kontonummer` varchar(30) default NULL,
  `preisgruppe` smallint(5) unsigned default NULL,
  `muellanteil` tinyint(1) default '0',
  `zahlungsart` smallint(5) unsigned default NULL,
  `standardtour` smallint(5) unsigned default NULL,
  `pruefen` tinyint(1) default '0',
  PRIMARY KEY  (`kundennr`),
  KEY `kundennr` (`kundennr`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `menu`;[n.!!e_w._!]
CREATE TABLE `menu` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `menu_mode` varchar(50) default NULL,
  `sub_id` int(11) default NULL,
  `sortierung` int(11) default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `mitarbeiter`;[n.!!e_w._!]
CREATE TABLE `mitarbeiter` (
  `id` int(11) NOT NULL auto_increment,
  `kennung` varchar(20) default NULL,
  `passwort` varchar(20) default NULL,
  `abteilung` smallint(6) default NULL,
  `art` smallint(6) default NULL,
  `name` varchar(50) default NULL,
  `vorname` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `mwst`;[n.!!e_w._!]
CREATE TABLE `mwst` (
  `id` bigint(20) NOT NULL auto_increment,
  `bezeichnung` char(2) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `packauftraege`;[n.!!e_w._!]
CREATE TABLE `packauftraege` (
  `id` int(11) NOT NULL auto_increment,
  `kundennr` smallint(5) unsigned NOT NULL default '0',
  `rechnungsnr` varchar(20) NOT NULL default '0',
  `packer` smallint(5) unsigned NOT NULL default '0',
  `kommissionaer` smallint(5) unsigned default NULL,
  `packstuecke` smallint(5) unsigned default NULL,
  `positionen` smallint(5) unsigned default NULL,
  `warenwert_netto` float unsigned default NULL,
  `tour` smallint(5) unsigned default NULL,
  `letzte_aenderung` int(10) unsigned default NULL,
  `lieferdatum` int(10) unsigned default NULL,
  `packdatum` int(10) unsigned default NULL,
  `reklamation` smallint(5) unsigned default NULL,
  `reklamationsbeschreibung` blob,
  `reklamation_vermeidbar` tinyint(1) default '0',
  PRIMARY KEY  (`id`),
  KEY `id` (`id`),
  KEY `lieferdatum` (`lieferdatum`),
  KEY `packdatum` (`packdatum`),
  KEY `kundennr` (`kundennr`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `preise_preisgruppe_artikel_staffelpreise`;[n.!!e_w._!]
CREATE TABLE `preise_preisgruppe_artikel_staffelpreise` (
  `preisgruppe_id` bigint(20) NOT NULL default '0',
  `artikel_id` bigint(20) NOT NULL default '0',
  `ab_menge` int(11) NOT NULL default '0',
  `preis` float NOT NULL default '0',
  `gueltig_ab` bigint(20) NOT NULL default '0',
  `gueltig_bis` bigint(20) NOT NULL default '0'
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `preisgruppen`;[n.!!e_w._!]
CREATE TABLE `preisgruppen` (
  `id` bigint(20) NOT NULL auto_increment,
  `bezeichnung` varchar(255) NOT NULL default '',
  `abgeleitet_von` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `rueckstaende`;[n.!!e_w._!]
CREATE TABLE `rueckstaende` (
  `id` int(11) NOT NULL auto_increment,
  `artikel` varchar(250) NOT NULL default '',
  `datum` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `touren`;[n.!!e_w._!]
CREATE TABLE `touren` (
  `id` int(11) NOT NULL auto_increment,
  `bezeichnung` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `user_art`;[n.!!e_w._!]
CREATE TABLE `user_art` (
  `id` smallint(6) NOT NULL default '0',
  `art` varchar(50) default NULL
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `vertreterliste`;[n.!!e_w._!]
CREATE TABLE `vertreterliste` (
  `id` int(11) default NULL,
  `bezeichnung` varchar(200) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `vorgangsart`;[n.!!e_w._!]
CREATE TABLE `vorgangsart` (
  `id` int(11) NOT NULL default '0',
  `bezeichnung` varchar(255) NOT NULL default ''
) TYPE=MyISAM;[n.!!e_w._!]
DROP TABLE IF EXISTS `zahlungsart`;[n.!!e_w._!]
CREATE TABLE `zahlungsart` (
  `id` int(11) NOT NULL default '0',
  `bezeichnung` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;[n.!!e_w._!]
